Installation 

- Drag and drop all files in to the Aurora Directory

(Don't drop the ytd in to themes, it won't work you have to replace the current ytd in the directory.)

Done

Ziplo